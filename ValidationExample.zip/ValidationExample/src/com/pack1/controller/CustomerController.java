package com.pack1.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import com.pack1.model.Customer;
import com.pack1.service.CustomerService;
//import com.pack1.validators.UserValidator;

@Controller  
@RequestMapping("customers")
public class CustomerController {
	@Autowired
	private CustomerService  customerservice;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder)
	{
	StringTrimmerEditor st=new StringTrimmerEditor(true);
	dataBinder.registerCustomEditor(String.class,st);
	}
	
	
	@RequestMapping("showForm")   
	public  String  showForm(Map<String,Object >  map)
	{
		Customer customer = new Customer();
		map.put("customer",customer);
		
			return "customerform";
		
	}
	
	
	


	
    @RequestMapping(value= "/insert",method=RequestMethod.POST)
	//public  String doAdd(@ModelAttribute Customer customer,@RequestParam String action, Map<String,Object>  map )
    public  String doAdd(@ModelAttribute @Valid Customer customer,BindingResult bindingResult, @RequestParam String action, Map<String,Object >  map )
    {
    	System.out.println("Binding Result:"+bindingResult);
		
			if (bindingResult.hasErrors()) {
				map.put("customer", customer);
				return "customerform";
			}
		
    	
		
		
			boolean flag = customerservice.add(customer);
		
		
		if(flag)
			return "success";
		else
			return "error";
	}
    
   
}

