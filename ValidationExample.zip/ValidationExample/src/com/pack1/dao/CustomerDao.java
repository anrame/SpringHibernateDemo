package com.pack1.dao;

import java.util.List;

import com.pack1.model.Customer;

public interface CustomerDao {
	public Boolean add(Customer c1);
	public List  getAllCustomers();
	public Customer getCustomer(int custid);
}
