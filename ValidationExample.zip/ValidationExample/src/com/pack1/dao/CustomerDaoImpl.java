package com.pack1.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.pack1.model.Customer;

import org.springframework.stereotype.Repository;

@Repository("customerdao")
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
    private SessionFactory  sessionFactory;
	
	@Override
	public Boolean add(Customer c1)
	{	
		try {
			System.out.println("Within customer dao add method");
	       sessionFactory.getCurrentSession().save(c1);
	       return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
			return false;
		}
	}
	
	@Override
	public Customer getCustomer(int custid) {
		return (Customer)sessionFactory.getCurrentSession().get(Customer.class,custid);
	}
	
	@Override
	public List  getAllCustomers() 
	{
		     return  sessionFactory.getCurrentSession().createCriteria(Customer.class).list();
	}
}
