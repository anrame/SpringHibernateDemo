package com.pack1.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Max;
//import javax.validation.constraints.Min;
//import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Digits;

import org.springframework.format.annotation.NumberFormat;
import org.hibernate.validator.constraints.Email;
import org.springframework.format.annotation.DateTimeFormat;

import java.text.SimpleDateFormat;
//import org.springframework.format.annotation.NumberFormat;
//import org.springframework.format.annotation.NumberFormat.Style;

@Entity
@Table(name="customer2")
public class Customer {
	@Id
	private int custid;
	@Column(length=20)
	@Size(min=2, max=20) 
	@NotNull(message="Please enter some name")
	private String custname;
	
	@NotNull
	@Past
	@DateTimeFormat(pattern="dd/MM/yyyy")
	private Date dob;
	@Column(length=20)
	@NotEmpty
	@Email
	private String emailid;
	
	@Transient
	private String datestring;
	@Column(columnDefinition = "number(10,2)")
	@Digits(integer = 10, fraction = 2, message = "The value of business amount can not be more than 10 digits and only 2 decimal values") 
	private double businessamount;
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public double getBusinessamount() {
		return businessamount;
	}
	public void setBusinessamount(double businessamount) {
		this.businessamount = businessamount;
	}
	public String getDatestring() {
		SimpleDateFormat dft = new SimpleDateFormat("dd-MMM-yyyy");
		datestring = dft.format(getDob());
		return datestring;
	}
	
	
}
