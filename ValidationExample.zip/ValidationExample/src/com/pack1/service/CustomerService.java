package com.pack1.service;

import java.util.List;

import com.pack1.model.Customer;

public interface CustomerService {
	public Boolean add(Customer customer);
	public List getAllCustomers();
	public Customer getCustomer(int custid);
}