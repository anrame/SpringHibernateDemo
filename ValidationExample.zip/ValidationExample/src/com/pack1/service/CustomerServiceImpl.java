package com.pack1.service;

import java.util.List;

import com.pack1.model.Customer;
import com.pack1.dao.CustomerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("customerservice")
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDao customerdao;
	
	@Override
	@Transactional
	public Boolean add(Customer customer) {
		System.out.println("Within customer service add method");
		return customerdao.add(customer);
	}
	
	@Transactional
	@Override
	public Customer getCustomer(int custid) {
		return customerdao.getCustomer(custid);
	}
	
	@Transactional
	@Override
	public List getAllCustomers()    
	{
		return customerdao.getAllCustomers();
	}
}
